function populate(s1,s2){
	var s1 = document.getElementById(s1);
	var s2 = document.getElementById(s2);
	s2.innerHTML = "";
	if(s1.value == "401"){
		var optionArray = ["|","abc|abc","amf|amf","cmf|cmf"];
	} else if(s1.value == "402"){
		var optionArray = ["|","Dmf|Dmf","xyz|xyz","zya|zya"];
	} else if(s1.value == "403"){
		var optionArray = ["|","AAA|AAA","BBB|BBB"];
	}
else if(s1.value == "404"){
		var optionArray = ["|","Shantanu Mishra|Shantanu Mishra","Aman Singh|Aman Singh","Ayaan Chishti|Ayaan Chishti","Nagaraja|Nagaraja","Ankur Das|Ankur Das","Madhu Shree HS|Madhu Shree HS","Anu Bharti|Anu Bharti","Rupanjana|Rupanjana","Imansu|Imansu","Vatsaan|Vatsaan","Arun Prakesh|Arun Prakesh","Bhavani|Bhavani","Kiran T|Kiran T"];
}
	for(var option in optionArray){
		var pair = optionArray[option].split("|");
		var newOption = document.createElement("option");
		newOption.value = pair[0];
		newOption.innerHTML = pair[1];
		s2.options.add(newOption);
	}
}

function selvalidate(){
var s1=document.getElementById(`slct1`).value;
if(s1=="Select Batch No"){
alert("Please Select Batch No");
return false;
}
return true;
}

function dsnme(){
const name = document.getElementById('slct2').value;
 sessionStorage.setItem("SNAME", name);
  return;
}


